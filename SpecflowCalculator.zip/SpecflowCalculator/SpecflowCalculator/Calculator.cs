﻿using System;

/* 
 * Add from “Extensions ➡ Manage Extensions ➡ Online” with the keyword “SpecFlow” 
 * Create a project with 'C# Class Library (.NET Core)'
 * Right click on the Solution & Add a new SpecFlow project ++ add 'xUnit' or other options as a test framework
 * Expand the project 'SpecFlow' project node in the Solution Explorer, right-click the “Dependencies” node and select the “Add Project Reference…” menu item to add project reference of as the original project
 * Bind & fill up the required methods & instances
 */


/* 
 * To generate LivingDoc report
 * Install the LivingDoc CLI as a global dotnet tool -> dotnet tool install --global SpecFlow.Plus.LivingDoc.CLI
 * Navigate to the Project Direct -> X:\...\SpecFlowCalculator\SpecFlowCalculator.Specs\bin\Debug\netcoreapp3.1
 * Run the LivingDoc CLI by using this command to generate the HTML report from that project location -> livingdoc test-assembly SpecFlowCalculator.Specs.dll -t TestExecution.json
*/

namespace SpecflowCalculator
{
    public class Calculator
    {

        public int FirstNumber { get; set; }
        public int SecondNumber { get; set; }


        // for addition
        public int Add()
        {
            return FirstNumber + SecondNumber;
        }

        // for subtraction
        public int Subtract()
        {
            return FirstNumber - SecondNumber;
        }

    }
}
