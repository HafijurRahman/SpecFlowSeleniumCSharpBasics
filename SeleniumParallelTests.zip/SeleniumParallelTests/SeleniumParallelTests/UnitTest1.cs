using NUnit.Framework;
using OpenQA.Selenium;

namespace SeleniumParallelTests
{

    [TestFixture]
    [Parallelizable]
    public class FirefoxTesting : Hooks
    {

        //Constructor - use 'ctor' double TAB short cut keys
        public FirefoxTesting() : base(BrowserType.Firefox)
        {

        } 


        [Test]
        public void FirefoxGoogleTest()
        {

            Driver.Navigate().GoToUrl("http://google.com/");
            IWebElement  element = Driver.FindElement(By.Name("q"));
            element.SendKeys("Automation");
            //System.Threading.Thread.Sleep(10000);
            element.SendKeys(Keys.Enter);
            //Driver.FindElement(By.Name("btnG")).Click();
            Assert.That(Driver.PageSource.Contains("Automation"),Is.EqualTo(true),
                                                "Text 'Automation' does NOT exist");
            Driver.Close();
        }
    }



    [TestFixture]
    [Parallelizable]
    public class ChromeTesting : Hooks
    {
        //Constructor
        public ChromeTesting() : base(BrowserType.Chrome)
        {
        }

        [Test]
        public void ChromeGoogleTest()
        {
            Driver.Navigate().GoToUrl("http://google.com/");
            IWebElement element = Driver.FindElement(By.Name("q"));
            element.SendKeys("Selenium");
            element.SendKeys(Keys.Enter);
            //Driver.FindElement(By.Name("btnG")).Click();
            Assert.That(Driver.PageSource.Contains("Selenium"), Is.EqualTo(true),
                                                "Text 'Selenium' does NOT exist");
            Driver.Close();

        }
    }



    [TestFixture]
    [Parallelizable]
    public class EdgeTesting : Hooks
    {

        //Constructor
        public EdgeTesting() : base(BrowserType.Edge)
        {
        }

        [Test]
        public void EdgeGoogleTest()
        {

            Driver.Navigate().GoToUrl("http://google.com/");
            IWebElement element = Driver.FindElement(By.Name("q"));
            element.SendKeys("Bird");
            element.SendKeys(Keys.Enter);
            //Driver.FindElement(By.Name("btnG")).Click();
            Assert.That(Driver.PageSource.Contains("Bird"), Is.EqualTo(true),
                                                "Text 'Bird' does NOT exist");
            Driver.Close();

        }
    }




}
