﻿using NUnit.Framework;
using OpenQA.Selenium.Chrome;
using OpenQA.Selenium.Edge;
using OpenQA.Selenium.Firefox;
using System;
using System.Collections.Generic;
using System.Text;

namespace SeleniumParallelTests
{

    public enum BrowserType
    {
        Chrome,
        Firefox,
        Edge
    }


    [TestFixture]
    public class Hooks : Base
    {
        private BrowserType _browserType;

        //Constructor
        public Hooks(BrowserType browser)
        {
            _browserType = browser;
            // Driver = new FirefoxDriver();
        }


        [SetUp]
        public void InitializeTest()
        {
            ChooseDriverInstance(_browserType);
        }


        public void ChooseDriverInstance(BrowserType browserType)
        {
            if (browserType == BrowserType.Chrome)
                Driver = new ChromeDriver();
            else if (browserType == BrowserType.Firefox)
                Driver = new FirefoxDriver();
            else if (browserType == BrowserType.Edge)
                Driver = new EdgeDriver();
        }


    }
}
