﻿using OpenQA.Selenium;
using System;
using System.Collections.Generic;
using System.Text;

namespace SeleniumParallelTests
{
   public class Base
    {

        //Holds the driver property, which will be used across framework or code
        public IWebDriver Driver { get; set; }


    }
}
